import java.util.Scanner;
class KMP_Pattern_Match{
	int m,n;
void FailureFunction(char P[],int F[]){
	int i=1,j=0;
	F[0]=0;
	m=P.length;
	while(i<m){
	   if(P[j]==P[i]){
		j++;
		F[i]=j;
		i++;
	}
	else if(j>0)
	   j=F[j-1];
	else
	  {
 	   F[i]=0;
	   i=i+1;
         }
   }
}
int kmp(char[] T,char[] P){
	int i=0,k=0;
	n=T.length;
	m=P.length;
	int F[]=new int[P.length];
	FailureFunction(P,F);
	while(i<n){
		if(T[i]==P[k]){
		 if(k==m-1)
			return i-k;
			k++;
			i++;
		}
		else if(k>0)
			k=F[k-1];
		      else{
			   i=i+1;
			}
	 }
	return -1;
 }
public static void main(String args[]){
	Scanner s1=new Scanner(System.in);
	Scanner s2=new Scanner(System.in);
	String T,P;
	System.out.println("Enter main and Substring");
	T=s1.nextLine();
	P=s2.nextLine();
	KMP_Pattern_Match KP=new KMP_Pattern_Match();
	int pos=KP.kmp(T.toCharArray(),P.toCharArray());
	if(pos==-1)
		System.out.println("Pattern not Found");
	else
		System.out.println("Pattern found at "+pos+" Position");
  }
}